﻿namespace ulda_atrisinajums
{
    partial class BUT_rekins
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.TB_vards = new System.Windows.Forms.TextBox();
            this.TB_velejums = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TB_platums = new System.Windows.Forms.TextBox();
            this.TB_garums = new System.Windows.Forms.TextBox();
            this.TB_augstums = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.but_izveidot = new System.Windows.Forms.Button();
            this.K = new System.Windows.Forms.Label();
            this.TB_kokmateriala = new System.Windows.Forms.TextBox();
            this.RB_rekins = new System.Windows.Forms.RichTextBox();
            this.BUT_fails = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Vārds";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // TB_vards
            // 
            this.TB_vards.Location = new System.Drawing.Point(149, 50);
            this.TB_vards.Name = "TB_vards";
            this.TB_vards.Size = new System.Drawing.Size(108, 20);
            this.TB_vards.TabIndex = 1;
            this.TB_vards.TextChanged += new System.EventHandler(this.TB_vards_TextChanged);
            // 
            // TB_velejums
            // 
            this.TB_velejums.Location = new System.Drawing.Point(149, 100);
            this.TB_velejums.Name = "TB_velejums";
            this.TB_velejums.Size = new System.Drawing.Size(108, 20);
            this.TB_velejums.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Vēlējums";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Lādītes izmērus(milimetros)";
            // 
            // TB_platums
            // 
            this.TB_platums.Location = new System.Drawing.Point(149, 190);
            this.TB_platums.Name = "TB_platums";
            this.TB_platums.Size = new System.Drawing.Size(108, 20);
            this.TB_platums.TabIndex = 5;
            this.TB_platums.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // TB_garums
            // 
            this.TB_garums.Location = new System.Drawing.Point(149, 223);
            this.TB_garums.Name = "TB_garums";
            this.TB_garums.Size = new System.Drawing.Size(108, 20);
            this.TB_garums.TabIndex = 6;
            // 
            // TB_augstums
            // 
            this.TB_augstums.Location = new System.Drawing.Point(149, 264);
            this.TB_augstums.Name = "TB_augstums";
            this.TB_augstums.Size = new System.Drawing.Size(108, 20);
            this.TB_augstums.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 190);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "platums";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 230);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "garums";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 271);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "augstums";
            // 
            // but_izveidot
            // 
            this.but_izveidot.Location = new System.Drawing.Point(149, 400);
            this.but_izveidot.Name = "but_izveidot";
            this.but_izveidot.Size = new System.Drawing.Size(79, 31);
            this.but_izveidot.TabIndex = 11;
            this.but_izveidot.Text = "Izveidot\r\n";
            this.but_izveidot.UseVisualStyleBackColor = true;
            this.but_izveidot.Click += new System.EventHandler(this.but_izveidot_Click);
            // 
            // K
            // 
            this.K.AutoSize = true;
            this.K.Location = new System.Drawing.Point(22, 327);
            this.K.Name = "K";
            this.K.Size = new System.Drawing.Size(124, 13);
            this.K.TabIndex = 12;
            this.K.Text = "Kokmateriāla cena E/m2";
            // 
            // TB_kokmateriala
            // 
            this.TB_kokmateriala.Location = new System.Drawing.Point(149, 327);
            this.TB_kokmateriala.Name = "TB_kokmateriala";
            this.TB_kokmateriala.Size = new System.Drawing.Size(108, 20);
            this.TB_kokmateriala.TabIndex = 13;
            // 
            // RB_rekins
            // 
            this.RB_rekins.Location = new System.Drawing.Point(149, 453);
            this.RB_rekins.Name = "RB_rekins";
            this.RB_rekins.Size = new System.Drawing.Size(79, 76);
            this.RB_rekins.TabIndex = 14;
            this.RB_rekins.Text = "";
            // 
            // BUT_fails
            // 
            this.BUT_fails.Location = new System.Drawing.Point(326, 406);
            this.BUT_fails.Name = "BUT_fails";
            this.BUT_fails.Size = new System.Drawing.Size(136, 24);
            this.BUT_fails.TabIndex = 15;
            this.BUT_fails.Text = "Ievietot failā";
            this.BUT_fails.UseVisualStyleBackColor = true;
            this.BUT_fails.Click += new System.EventHandler(this.BUT_fails_Click);
            // 
            // BUT_rekins
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 602);
            this.Controls.Add(this.BUT_fails);
            this.Controls.Add(this.RB_rekins);
            this.Controls.Add(this.TB_kokmateriala);
            this.Controls.Add(this.K);
            this.Controls.Add(this.but_izveidot);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TB_augstums);
            this.Controls.Add(this.TB_garums);
            this.Controls.Add(this.TB_platums);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TB_velejums);
            this.Controls.Add(this.TB_vards);
            this.Controls.Add(this.label1);
            this.Name = "BUT_rekins";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TB_vards;
        private System.Windows.Forms.TextBox TB_velejums;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TB_platums;
        private System.Windows.Forms.TextBox TB_garums;
        private System.Windows.Forms.TextBox TB_augstums;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button but_izveidot;
        private System.Windows.Forms.Label K;
        private System.Windows.Forms.TextBox TB_kokmateriala;
        private System.Windows.Forms.RichTextBox RB_rekins;
        private System.Windows.Forms.Button BUT_fails;
    }
}

